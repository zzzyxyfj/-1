package com.example;

import com.example.entity.User;

import java.io.*;

public class main {
    public static void main(String[] args) throws Exception {
        User user = new User(18, "xiuxian", "123456");
     //   serialize(user);
         unserialize();
    }
    public static void serialize(Object obj) throws Exception {
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("ser.bin"));
        oos.writeObject(obj);
    }
    public static void  unserialize() throws Exception {
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream("ser.bin"));
        User user = (User)ois.readObject();
        System.out.println(user);
    }
}
