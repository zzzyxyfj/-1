package com.example.entity;
import java.io.Serializable;

public class User implements Serializable {

   private static final long serialVersionUID = 6346166741806450789L;
  // private static final long serialVersionUID = 1L;
    private int age;
    private String username;
    private String password;

    public User(int age, String username, String password) {
        this.age = age;
        this.username = username;
        this.password = password;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "User{" +
                "age=" + age +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                '}';
    }

    //重写readObject()方法
    private void readObject(java.io.ObjectInputStream in) throws Exception {
        //执行默认的readObject()方法
        in.defaultReadObject();
        //执行打开计算器程序命令
        Runtime.getRuntime().exec("calc.exe");
    }

}
