package com.example.controller;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Base64;

@WebServlet("/deser")
public class DeserializeServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");
        // 获取请求体中的序列化数据
        String basestr = req.getParameter("str");
        // 对序列化数据进行Base64解码
        byte[] decodeStr = Base64.getDecoder().decode(basestr);
        // 创建ByteArrayInputStream对象，用于读取解码后的序列化数据
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(decodeStr);
        // 创建ObjectInputStream对象，用于反序列化数据
        ObjectInputStream ois = new ObjectInputStream(byteArrayInputStream);
        try {
            // 读取反序列化数据并转换为Java对象
            Object o = ois.readObject();
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } finally {
            // 关闭ObjectInputStream对象
            ois.close();
            // 返回响应，用于测试反序列化漏洞
            resp.getWriter().write("反序列化漏洞测试");
        }
    }
}
